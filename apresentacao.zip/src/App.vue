<template>
  <v-app>
    <v-app-bar
      app
      color="primary"
      dark
    >
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png"
          transition="scale-transition"
          width="40"
        />

        <span class="mr-1 title">Felipe Vieira</span>
        
      </div>

      <v-spacer></v-spacer>

      <v-btn v-on:click="componente = 'Inicial'" v-bind:class="[componente == 'Inicial' ? 'v-btn--active' :'']" text>
        <span class="mr-2">Inicial</span>
      </v-btn>
      
      <v-btn v-on:click="componente = 'Conhecimentos'" v-bind:class="[componente == 'Conhecimentos' ? 'v-btn--active' :'']" text>
        <span class="mr-2">Conhecimentos</span>
      </v-btn>
    </v-app-bar>

    <v-content>
      <component v-bind:is="componente"></component>
    </v-content>
  </v-app>
</template>

<script>
import Inicial from './components/Inicial';
import Conhecimentos from './components/Conhecimentos';

export default {
  name: 'App',

  components: {
    Inicial,
    Conhecimentos
  },

  data: () => ({
    componente: 'Inicial',
  }),
};
</script>
// <style lang="scss">
//   @import "../node_modules/ag-grid-community/dist/styles/ag-grid.css";
//   @import "../node_modules/ag-grid-community/dist/styles/ag-theme-balham.css";
// </style>
