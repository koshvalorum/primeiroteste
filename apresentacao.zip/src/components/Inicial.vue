<template>
  <v-container>
    <v-row class="text-center">
      <v-col cols="12">
        <v-img
          :src="require('../assets/inicial.jpg')"
          class="my-3"
          contain
          height="200"
        />
      </v-col>

      <v-col class="mb-4">
        <!-- <h1 class="display-2 font-weight-bold mb-3">
         Felipe Vieira de Souza
        </h1>
        <h2 class="display-2 font-weight-bold mb-2">
         Desenvolvedor
        </h2> -->

        <p> 
        <span class="subheading font-weight-bold">
          Felipe Vieira de Souza
        </span><br>
        <span class="subheading font-weight-regular">
          desenvolvedor
        </span>
        </p>
      </v-col>

    </v-row>
    <v-row>
      <v-col>
        <p class="text-justify">
          Com envolvimento em tecnologia iniciado em 1988 com um cursinho de BASIC quando os pc’s ainda não eram dotados de mais do que 640 quilobytes de memória, iniciei profissionalmente na metade da década de 1990, refatorando código para aplicativos de controle de corretoras de seguros em prevenção contra o bug do milênio.  Segui trabalhando a partir de 1997 em transportadora, também com o Visual Basic na emissão de conhecimento e manifestos de transporte rodoviário de cargas.  Na Caixa, desde o início de 2012 integro a equipe de inovação e desenvolvimento da SUBAN, inicialmente sob a GEOPE, mas rapidamente transferida para a GEBAN, onde no método Ágile, com SCRUM, desenvolvi o back-end do aplicativo de acertos de convênios SICAP/SICOB(SQL Server), o aplicativo de controle de Ausências (VB.NET), serviço de uploads (SQL Server/asp.net), front-end da Matriz de Acessos em HTML5 com AngularJS, Aplicativo de Conferência de Cheques (fraude prevenida - VB.NET), importação e manutenção de base de dados de imagens de Cheques (SQL Server), e colaboração em outros projetos da célula de inovação, tendo feito sugestões que levaram à mudanças no estilo de trabalho da equipe, como a implantação do DBA, tarefa antes fracionada, e o grupo de trabalho de padronização, que levou a equipe a desenvolver o site em uma plataforma unificada.  Atualmente estou trabalhando no desenvolvimento do novo Acertos & RCC, especificamente no back-end com o middleware NodeJS, e estrutura de dados em MongoDB.
        </p>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  export default {
    name: 'Inicial',

    data: () => ({
      
      
    }),
  }
</script>
