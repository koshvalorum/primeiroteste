<template>
  <v-container>
    <v-row class="text-center">
      <v-col cols="12">
        <v-img
          :src="require('../assets/qualificacoes.jpg')"
          class="my-3"
          contain
          height="200"
        />
      </v-col>

      <v-col class="mb-4">
        <!-- <h1 class="display-2 font-weight-bold mb-3">
         Felipe Vieira de Souza
        </h1>
        <h2 class="display-2 font-weight-bold mb-2">
         Desenvolvedor
        </h2> -->

        <p> 
        <span class="subheading font-weight-bold">
          Felipe Vieira de Souza
        </span><br>
        <span class="subheading font-weight-regular">
          Conhecimento, Experiência e Qualificações
        </span>
        </p>

        
 
      </v-col>
    </v-row>

<v-content>
  <v-layout justify-center align-center wrap>
    <v-flex fill-height>
       <ag-grid-vue style="width: 500px; height: 500px;"
                 class="ag-theme-balham"
                 :columnDefs="columnDefs"
                 :rowData="rowData">
        </ag-grid-vue>
    </v-flex>
</v-layout>
</v-content>

  </v-container>


</template>

<script>

import {AgGridVue} from "ag-grid-vue";

  export default {
    name: 'Qualificacoes',

    data: () => ({
      columnDefs: [],
      rowData: []
    }),  
    components: {
      AgGridVue
    },
    beforeMount () {
      this.columnDefs = [
        {headerName:"Make", field:"make"},
        {headerName:"Model",field:"model"},
        {headerName:"Price",field:"price"}
      ];
      this.rowData = [
        {make:"Toyota", model:"Celica",price:35000},
        {make:"Ford", model:"Mondeo",price:25000},
        {make:"Porsche", model:"Boxter",price:38000},
        {make:"Tesla", model:"x",price:85000}
      ]
    }
  }
</script>
<style lang = "scss"> 
@import "../../node_modules/ag-grid-community/dist/styles/ag-grid.css";
@import "../../node_modules/ag-grid-community/dist/styles/ag-theme-balham.css"


</style>