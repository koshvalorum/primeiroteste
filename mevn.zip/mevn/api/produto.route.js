// cliente.model.js
const express = require('express');
const produtoRoutes = express.Router();

// Require Post model in our routes module
let Produto = require('./produto.model');

// Defined get data(index or listing) route
produtoRoutes.route('/').get(function (req, res) {
    Produto.find(function(err, produtos){
    if(err){
      res.json(err);
    }
    else {
      res.json(produtos);
    }
  });
});

module.exports = produtoRoutes;