// cliente.model.js

const express = require('express');
const clienteRoutes = express.Router();

// Require Post model in our routes module
let Cliente = require('./cliente.model');

// Defined store route
clienteRoutes.route('/add').post(function (req, res) {
  let cliente = new Cliente(req.body);
  cliente.save()
    .then(() => {
      res.status(200).json({'Cliente': 'adicionado com sucesso'});
    })
    .catch(() => {
      res.status(400).send("Impossível Salvar");
    });
});

// Defined get data(index or listing) route
clienteRoutes.route('/').get(function (req, res) {
    Cliente.find(function(err, clientes){
    if(err){
      res.json(err);
    }
    else {
      res.json(clientes);
    }
  });
});

// Defined edit route
clienteRoutes.route('/edit/:id').get(function (req, res) {
  let id = req.params.id;
  Cliente.findById(id, function (err, cliente){
      if(err) {
        res.json(err);
      }
      res.json(cliente);
  });
});

//  Defined update route
clienteRoutes.route('/update/:id').post(function (req, res) {
    Cliente.findById(req.params.id, function(err, cliente) {
    if (!cliente)
      res.status(404).send("nenhum dado a localizar");
    else {
        cliente.nome = req.body.nome;
        cliente.endereco = req.body.endereco;
        cliente.telefone = req.body.telefone;
        cliente.cpfcnpj = req.body.cpfcnpj;
        cliente.produtos = req.body.produtos;
        post.save().then(() => {
          res.json('Update complete');
      })
      .catch(() => {
            res.status(400).send("unable to update the database");
      });
    }
  });
});

// Defined delete | remove | destroy route
clienteRoutes.route('/delete/:id').delete(function (req, res) {
    Cliente.findByIdAndRemove({_id: req.params.id}, function(err){
        if(err) res.json(err);
        else res.json('Successfully removed');
    });
});

module.exports = clienteRoutes;