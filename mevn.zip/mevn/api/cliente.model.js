// post.model.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Post
let Cliente = new Schema({
  title: {
    type: String
  },
  body: {
    type: String
  }
},{
    collection: 'clientes'
});

module.exports = mongoose.model('Cliente', Cliente);