<template>
  <div>
    <h1>Cadastrar Produto</h1>
    <form @submit.prevent="addCliente">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>CPF/CNPJ cliente:</label>
            <input type="text" class="form-control" v-model="produto.cpfcnpj">
          </div>
          <div class="form-group">
            <label>Valor Proposta</label>
            <input type="text" class="form-control" v-model="produto.valor">

            <label>Data Proposta:</label>
            <input type="text" class="form-control" v-model="produto.dataproposta">

            <label>Produto</label>
            <!-- <dropdown :options="produtos" :selected="object" v-on:updateOption="methodToRunOnSelect"></dropdown> -->





          </div>

          
        </div>
        <!-- </div>
        <div class="row"> -->
          <div class="col-md-6">
            <div class="form-group">
              <label>Endereco:</label>
              <textarea class="form-control" v-model="cliente.body" rows="4"></textarea>
            </div>
            <div class="form-group">
            <label>Telefone:</label>
            <input type="text" class="form-control" v-model="cliente.title">
          </div>
          </div>
        </div><br />
        <div class="form-group">
          <button class="btn btn-primary">Create</button>
        </div>
    </form>
  <listar :key="componentKey"  />
  
  </div>

</template>

<script>

import listar from '../components/IndexComponent';
    export default {
        data(){
        return {
          cliente:{},
          produto:{},
          produtos:[],
          componentKey : 0,
          config: {
            options: [
                {
                    value: "capitaliz"
                },
                {
                    value: "seguro"
                },
                {
                    value: "cdc"
                }
            ],
            prefix: "The",
            backgroundColor: "green"
          }
        }
    },
    created(){

    let urlprod = 'http://localhost:4000/produto'
      this.axios.get(urlprod).then(response =>{
        this.produtos = response.data;
      })
    },
    
    components:{listar},
    methods: {
      addCliente(){
        let uri = 'http://localhost:4000/cliente/add';
        this.axios.post(uri, this.post).then(() => {
          this.componentKey += 1;
            //this.$router.push({name: 'posts'});
          });
      }
    }
  }
</script>