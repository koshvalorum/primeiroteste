// IndexComponent.vue

<template>
  <div>
      <h1>Posts</h1>
        <div class="row">
          <div class="col-md-10"></div>
          <div class="col-md-2">
            <router-link :to="{ name: 'create' }" class="btn btn-primary">Create Post</router-link>
          </div>
        </div><br />

        <table class="table table-hover">
            <thead>
            <tr>
              <th>Nome</th>
              <th>CPF/CNPJ</th>
              <th>Telefone</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <tr v-for="cliente in clientes" :key="cliente._id">
                  <td>{{ cliente.nome }}</td>
                  <td>{{ cliente.cpfcnpj }}</td>
                  <td>{{ cliente.telefone }}</td>
                  <td><router-link :to="{name: 'edit', params: { id: post._id }}" class="btn btn-primary">Edit</router-link></td>
                  <td><button class="btn btn-danger" @click.prevent="deletePost(post._id)">Delete</button></td>
                </tr>
            </tbody>
        </table>
  </div>
</template>

<script>
  export default {
      data() {
        return {
          clientes: []
        }
      },
      created() {
      let uri = 'http://localhost:4000/cliente';
      this.axios.get(uri).then(response => {
        this.clientes = response.data;
      });

    },
    methods: {
      deletePost(id)
      {
        let uri = `http://localhost:4000/cliente/delete/${id}`;
        this.axios.delete(uri).then(() => {
          this.posts.splice(this.posts.indexOf(id), 1);
        });
      }
    }
  }
</script>