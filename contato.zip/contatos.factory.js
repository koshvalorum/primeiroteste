(function () {
    'use strict';

    angular
        .module('appContato')
        .factory('contatosFactory', contatosFactory);

    contatosFactory.$inject = ['$rootScope', '$q', '$http', 'mainService', '$filter', '$window'];

    function contatosFactory($rootScope, $q, $http, mainService, $filter, $window) {

        var usuario = {};

        var service = {
            getUsuario: getUsuario,
            listContatos: listContatos,
            getArquivos: getArquivos,
            getDados: getDados,
            putResposta: putResposta,
            getUnidades: getUnidades
        };

        return service;


        function getUnidades() {
            return mainService.SQLService('getFromStoredProcedure', { Procedure: 'contato.dbo.getEncaminhamentos', Parameters: {}, MatrixAlways: true, PropAlways: true }).then(function(response){ return response.d;})
        }

        function putResposta(resposta) {
            return mainService.SQLService('ExecuteStoredProcedure', { Procedure: 'contato.dbo.spResponde', Parameters: resposta }).then(function (response) { return response; })
        }

        function getDados(idArquivo) {
            return mainService.SQLService(
                'GetFromStoredProcedure',
                {
                    Procedure: 'uploads.arquivos.getDados'
                    , Parameters: { 'id': idArquivo }
                    , MatrixAlways: true, PropAlways: true
                }).then(function (response) {
                    var bytearray = new Uint8Array(response.d[0].dados);
                    var blob = new Blob([bytearray], { type: response.d[0].contentType });
                    
                    return $window.URL.createObjectURL(blob)
                });
        }

        function getArquivos(idContato) {
            return mainService.SQLService(
                'GetFromStoredProcedure',
                {
                    Procedure: 'uploads.arquivos.spListArquivos'
                    ,Parameters: {'idOrigem' : idContato, 'idrotina': '2'}
                    ,MatrixAlways: true, PropAlways : true
                }).then(function (response) {
                    return mainService.convertDates(response.d);
                })

        }
        
        function listContatos() {
            return mainService.SQLService(
                'GetFromStoredProcedure',
                {
                    Procedure: 'contato.dbo.listar'
                    , Parameters: {}
                    , MatrixAlways: true, PropAlways: true
                }).then(function (response) {
                    return mainService.convertDates(response.d);
                });
        }


        function getUsuario() {

            if (Object.keys(usuario).length > 0) {
                return $q(function (resolve, reject) { resolve(usuario); })
            }

            var promisses = [getMatricula(), getUnidadeAdm(), getUnidadeFis(), getGrupos(), getFuncao(), getFuncaoEventual()];

            return $q.all(promisses).then(function (response) {
                    return usuario;
                }
            );
        }

        function getMatricula() {
            return $http.post('../../core/services/InovService.asmx/GetUsuario', {}).then(function (response) {
                usuario.matricula = angular.copy(response.data.d.matricula);
                usuario.nome = angular.copy(response.data.d.nome);
                return(response);
            });
        }

        function getUnidadeAdm() {
            return $http.post('../../core/services/InovService.asmx/GetUnidade', { Tipo: 0 }).then(function (response) {
                usuario.unidade = angular.copy(response.data.d);
                usuario.unidade.cgc = angular.copy(usuario.unidade.cod);

                delete usuario.unidade.cod;
                return(response);
            });
        }

        function getUnidadeFis() {
            return $http.post('../../core/services/InovService.asmx/GetUnidade', { Tipo: 1 }).then(function (response) {
                usuario.unidadeFisica = angular.copy(response.data.d);
                return(response);
            });
        }

        function getGrupos() {
            return $http.post('../../core/services/InovService.asmx/GetGrupos', {}).then(function (response) {
                usuario.grupos = angular.copy(response.data.d);
                return(response);
            });
        }

        function getFuncao() {
            return $http.post('../../core/services/InovService.asmx/GetFuncao', { Tipo: 0 }).then(function (response) {
                usuario.funcao = angular.copy(response.data.d);
                return(response);
            });
        }

        function getFuncaoEventual() {
            return $http.post('../../core/services/InovService.asmx/GetFuncao', { Tipo: 1 }).then(function (response) {
                if (Object.keys(response.data.d).length > 0) {
                    usuario.funcao = angular.copy(response.data.d);
                    return(response);
                }
            });
        }
    }
})();