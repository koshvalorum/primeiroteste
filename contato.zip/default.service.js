var $Dev;
(function() {
  'use strict';
  
  angular
    .module('appContato')
    .service('mainService', mainService)
  
  

  angular
    .module('appContato')
    .filter('netDate', netDate);

  function netDate() {
      //data como string que veio do .NET (ou via SQL)
      return function SQLtoDate(date) {
          //return new Date(Number(date.replace("/Date(","").replace(")/",""))) 
          return new Date(new Date(Number(date.replace("/Date(", "").replace(")/", ""))).toISOString().replace('T', ' ').substring(0, 19)) //com fuso hor�rio
      }
  }

  mainService.$inject = ['$log', '$http', '$q', '$filter', '$templateRequest', '$compile']

  function mainService($log, $http, $q, $filter, $templateRequest, $compile) {

    var svc = this;
    svc.get = get;
    svc.get2 = get2;
    svc.fail = fail;
    svc.server = server;
    svc.convertDates = convertDates;
    svc.InovService = InovService;
    svc.SQLService = SQLService;
    svc.DevService = DevService;
    svc.sendEmail = sendEmail;



    function get(response) {
        return response.data;
    } 

    function get2(response) {
        return response.data.d;
    }

    function fail(error) {
        $log.log(error.data);
        // The catch block of a promise must return a rejected promise to maintain the exception in the promise chain. Como?
        return error.data;
    }
    
    function server(asmx, webmethod, params){
        return $http.post(asmx + '/' + webmethod, params || {})
        .then(get, fail);
    }

    function convertDates(arrayDados) {
        return $q(function(ok, falhou){
            angular.forEach(arrayDados, function(obj, i) {
                angular.forEach(obj, function(value, prop) {            
                    if (/^\/Date\(/.test(obj[prop])) {              
                        obj[prop] = $filter('netDate')(value);              
                    }
                });
            });
            ok(arrayDados);
        })
    }
    
    function sendEmail(headers, template, scope){
        function envia(){
            return svc.SQLService('GetFromStoredProcedure', {
                Procedure: '[PortalInovacao].[portal].[spSendEmail]',
                Parameters: headers,
                MatrixAlways: false,
                PropAlways: true
            });
         }

         if (template) {
            $templateRequest(template).then(function(html){
                headers.body = '';
                _.each($compile(angular.element(html))(scope), function(v,k){
                    headers.body += (v.outerHTML || '');
                });
                return envia();
            })
        } else
        return envia();
    }

      /* .NET Services */
    function InovService(webmethod, params) {
        return $http.post('/core/services/InovService.asmx/' + webmethod, params || {})
        .then(get, fail);
    }

    function SQLService(webmethod, params) {
        return $http.post('/core/services/SQLService.asmx/' + webmethod, params || {})
        .then(get, fail);
    }

    function DevService(webmethod, params) {
        return $http.post('/core/services/DevService.asmx/' + webmethod, params || {})
        .then(get, fail);
    }


    return svc;

    }
})()



