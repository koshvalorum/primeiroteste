﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class arquivo
    Inherits System.Web.UI.Page

    Private Function GetData(query As String) As DataTable
        Dim dt As New DataTable()
        Dim constr As String = ConfigurationManager.ConnectionStrings("prod").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand(query)
                Using sda As New SqlDataAdapter()
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(dt)
                End Using
            End Using
            Return dt
        End Using
    End Function


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim bytes As Byte() = DirectCast(GetData(Convert.ToString("SELECT Data FROM contato.dbo.tblFiles WHERE Id =" & Request("idarquivo"))).Rows(0)("Data"), Byte())
        Dim base64String As String = Convert.ToBase64String(bytes, 0, bytes.Length)
        imagem.ImageUrl = Convert.ToString("data:image/png;base64,") & base64String
    End Sub
End Class
