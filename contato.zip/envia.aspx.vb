﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Data
'Imports System.Threading


Partial Class VB
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim arquivos As HttpFileCollection = Request.Files()
        For x As Integer = 0 To arquivos.Count - 1 'Each key As String In arquivos.Keys
            Dim arquivo As HttpPostedFile = arquivos(x)
            Dim filename As String = arquivo.FileName
            Dim contentType As String = arquivo.ContentType
            Dim reader As SqlDataReader, idarquivo As Long

            Using fs As Stream = arquivo.InputStream
                Using br As New BinaryReader(fs)
                    Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))
                    Dim constr As String = ConfigurationManager.ConnectionStrings("prod").ConnectionString
                    Using conn As New SqlConnection(constr)
                        Dim query As String = "insert into contato.dbo.tblFiles values (@Name, @ContentType, @contato, @Data) select @@identity as idArquivo"
                        Using cmd As New SqlCommand(query)
                            cmd.Connection = conn
                            cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = filename
                            cmd.Parameters.Add("@contentType", SqlDbType.VarChar).Value = contentType
                            cmd.Parameters.Add("@contato", SqlDbType.BigInt).Value = Request("idContato")
                            If arquivo.ContentLength / 1024 <= 250 Then
                                cmd.Parameters.Add("@data", SqlDbType.VarBinary).Value = bytes
                            Else
                                cmd.Parameters.Add("@data", SqlDbType.VarBinary).Value = DBNull.Value
                            End If
                            conn.Open()
                            reader = cmd.ExecuteReader()
                            If reader.Read Then
                                idarquivo = reader("idArquivo")
                            End If

                            If arquivo.ContentLength / 1024 > 250 Then
                                Dim filepath As String = "\\10.123.36.246\pub\Uploads\"
                                filename = CStr(idarquivo) & "-" & filename

                                arquivo.SaveAs(String.Format("{0}{1}", filepath, filename))
                            End If

                            conn.Close()
                        End Using
                    End Using
                End Using
            End Using

        Next





    End Sub
End Class
