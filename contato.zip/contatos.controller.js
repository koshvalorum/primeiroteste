(function () {
    'use strict';

    angular
       .module('appContato')
       .controller('contatosController', contatosController);

    contatosController.$inject = ['$q', 'contatosFactory', '$ngBootbox', '$filter', '$http'];

    function contatosController($q,  contatosFactory, $ngBootbox, $filter, $http) {

        //Variáveis
        var vm = this;
        var f = contatosFactory;
        vm.usuario = {};
        vm.mostraupload = false;
        vm.mostragravar = true;
        vm.contatos = [];
        vm.contato = {}
        vm.contato.arquivos = [];
        vm.contato.mensagem = '';
        vm.urlarquivo = null;
        vm.resposta = {};
        vm.resposta.areaResponsavel = '';
        vm.respostaAssinada = false;
        vm.unidades = [];
        vm.arquivoselecionado = 0;
        

        //Funções
        vm.pegaArquivos = pegaArquivos;
        vm.liberaArquivo = liberaArquivo;
        vm.janelaResposta = janelaResposta;
        vm.adicionarassinatura = adicionarassinatura;
        vm.Responder = Responder;
        vm.resizeIframe = resizeIframe;

        activate();

        function activate() {
            var promisses = [f.getUsuario(),f.listContatos(), f.getUnidades()];
            $q.all(promisses).then(function (response) {
                vm.usuario = response[0];
                vm.contatos = response[1];
                vm.unidades = response[2];
                console.log(response[2]);
            });
        }

        function pegaArquivos(idContato) {

            vm.contato.id = idContato;
            

            vm.contato.mensagem = _.find(vm.contatos, function (contato) { return contato.id == idContato }).mensagem;
            vm.contato.nome = _.find(vm.contatos, function (contato) { return contato.id == idContato }).nome;
            vm.contato.data = _.find(vm.contatos, function (contato) { return contato.id == idContato }).data;
            vm.contato.qtdresp = _.find(vm.contatos, function (contato) { return contato.id == idContato }).qtdresp;
            f.getArquivos(idContato).then(function (response) {
               vm.contato.arquivos = response;
               console.log('contato com ' + vm.contato.arquivos.length + ' arquivos.');

               vm.resposta.idcontato = idContato;
               vm.respostaAssinada = false;
               vm.resposta.resposta = 'Prezado ' + vm.contato.nome.toLowerCase().capitalize() + '\n\nEm resposta ao seu contato:\n\n' + vm.contato.mensagem + ' \n em ' + vm.contato.data + ' \n\n Informamos que,'
               $('#addassinatura').removeAttr('disabled');

            })
            
        }

        function resizeIframe(obj) {
            obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
        }

        function liberaArquivo(arquivo) {
            
            vm.arquivoselecionado = arquivo.id;

            $('#conteudoarquivo').attr('src', '../../apps_legado/_img/loading.gif');


            $q.all([f.getDados(arquivo.id)]).then(function (response) {
                console.log(arquivo.nomeOriginal);
                $('#conteudoarquivo').attr('src' ,response[0]);
                window.open(response[0]);
            });

        }
        
        function janelaResposta() {
            
            vm.contato.qtdresp = 0;

        }

        function adicionarassinatura() {
            $('#addassinatura').attr('disabled', 'disabled');
            vm.resposta.idcontato = vm.contato.id;
            vm.resposta.responsavel = vm.usuario.matricula;
            vm.resposta.resposta = vm.resposta.resposta + '\n\n\nAtenciosamente, \n' + vm.usuario.nome.toLowerCase().capitalize() + ' - C' + ('000000' + vm.usuario.matricula).slice(-6) + '\n' + vm.usuario.funcao.nome.toLowerCase().capitalize()
            vm.resposta.resposta = vm.resposta.resposta + '\n\nGEBAN02 - Otimização e Inovação em Processos'
            vm.respostaAssinada = true;
            console.log(vm.resposta);
            
        }
        
        function Responder() {
            if (!vm.respostaAssinada) {
                alert("primeiro adicione a Assinatura");
            } else {
                $('#modalResposta').modal('hide');
                vm.resposta.resposta = vm.resposta.resposta.replace(/\n/g, "<br />");
                f.putResposta(vm.resposta).then(function (response) {
                    alert("resposta registrada e enviada");
                });
            }
        }
    }


    function encode (input) {
        var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;

        while (i < input.length) {
            chr1 = input[i++];
            chr2 = i < input.length ? input[i++] : Number.NaN; // Not sure if the index 
            chr3 = i < input.length ? input[i++] : Number.NaN; // checks are needed here

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output += keyStr.charAt(enc1) + keyStr.charAt(enc2) +
                      keyStr.charAt(enc3) + keyStr.charAt(enc4);
        }
        return output;
    }


})()


String.prototype.capitalize = function () {
    return this.replace(/(?=\b)([a-z])(?=[a-z]{2})/g, function (g0) { return (g0.toUpperCase()); });
}