(function () {
    'use strict';

    angular
        .module('appContato')
        .factory('contatoFactory', contatoFactory);

    contatoFactory.$inject = ['$rootScope','$q', '$http', 'mainService'];

    function contatoFactory($rootScope, $q, $http, mainService) {

        var usuario = {};

        var service = {
            getClientes: getClientes,
            getProdutos: getProdutos,
            getProdutosCliente: getProdutosCliente,
            gravaProduto: gravaProduto
        };

        return service;

        function gravaProduto(produto) {
            return mainService.SQLService('ExecuteStoredProcedure', { Procedure: 'fvscliprod.dbo.putProspeccao', Parameters: produto }).then(function (response) { return response;})
        }

        function getProdutosCliente(cliente) {
            return mainService.SQLService(
                'GetFromStoredProcedure',
                {
                    Procedure: 'fvscliprod.dbo.getProdutosCliente'
                    , Parameters: {cliente}
                    , MatrixAlways: false, PropAlways: true
                }).then(function (response) {
                    return (response.d);
                });
        }

        function getClientes() {
            return mainService.SQLService(
                'GetFromStoredProcedure',
                {
                    Procedure: 'fvscliprod.dbo.getClientes'
                    , Parameters: {}
                    , MatrixAlways: false, PropAlways: true
                }).then(function (response) {
                    return (response.d);
                });
        }

        function getProdutos() {
            return mainService.SQLService(
                'GetFromStoredProcedure',
                {
                    Procedure: 'fvscliprod.dbo.getProdutos'
                    , Parameters: {}
                    , MatrixAlways: false, PropAlways: true
                }).then(function (response) {
                    return (response.d);
                });
        }
       
        
    }
})();