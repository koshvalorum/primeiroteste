(function () {
    'use strict';

    angular
       .module('appContato')
       .controller('contatoController', contatoController);

    contatoController.$inject = ['$q', 'contatoFactory'];
    






    function contatoController($q, contatoFactory) {
        //Variáveis
        var vm = this;
        var f = contatoFactory;
        vm.produto = {};
        vm.produtos = [];
        vm.produto.cpfcnpj = '';
        vm.prodselecionado = {};
        vm.nomecliente = 'nenhum cliente selecionado';
        //funcoes
        vm.gravar = gravar;
        vm.procuracliente = procuracliente;
     

        activate();

        function procuracliente(evento){
            var achou = 0
            vm.clientes.forEach(cliente =>{
                if (cliente.cpfcnpj == evento.target.value){
                    vm.nomecliente = cliente.nome + "    " + cliente.telefone;
                    achou = 1;
                }
            });
            //console.log('cnpj',evento.target.value.toString(),  validacnpj(evento.target.value.toString()));
            //console.log('cpf', validacpf(evento.target.value));


            if (achou == 0) vm.nomecliente = 'nenhum cliente selecionado';

            if (achou == 0 && evento.target.value.length>0 && !validacnpj(evento.target.value) && !validacpf(evento.target.value)){
                vm.nomecliente += ' não é um cpf/cnpj válido';
            }

            
        }

        function activate() {
           
            var promisses = [f.getClientes()];
            $q.all(promisses).then(function (response) {
                vm.clientes = response[0]
                console.log('cli', vm.clientes);
            });

            var promessas = [f.getProdutos()];
            $q.all(promessas).then(resposta => {
                vm.produtos = resposta[0];

            });
            
        }

        



        function gravar() {

            vm.produto.produto = vm.prodselecionado.id;

            console.log('gravar', vm.produto, vm.prodselecionado)

            return false;

            $q.all([f.gravaProduto(vm.produto)]).then(function (response) {
                console.log('vai abrir a janela de importar');
                vm.mostragravar = false;
                vm.mostraupload = true;
            });
        }




        function validacpf(strCPF) {
            var Soma;
            var Resto;
            Soma = 0;
          if (strCPF == "00000000000") return false;
             
          for (var i=1; i<=9; i++) Soma = Soma + parseInt(strCPF.substring(i-1, i)) * (11 - i);
          Resto = (Soma * 10) % 11;
           
            if ((Resto == 10) || (Resto == 11))  Resto = 0;
            if (Resto != parseInt(strCPF.substring(9, 10)) ) return false;
           
          Soma = 0;
            for (var i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i-1, i)) * (12 - i);
            Resto = (Soma * 10) % 11;
           
            if ((Resto == 10) || (Resto == 11))  Resto = 0;
            if (Resto != parseInt(strCPF.substring(10, 11) ) ) return false;
            return true;
        }
       




        function validacnpj(cnpj) {

            cnpj = cnpj.replace(/[^\d]+/g, '');
        
            if (cnpj == '') return false;
        
            if (cnpj.length != 12 && cnpj.length != 14)
                return false;
        
         
            if (cnpj == "00000000000000" ||
                cnpj == "11111111111111" ||
                cnpj == "22222222222222" ||
                cnpj == "33333333333333" ||
                cnpj == "44444444444444" ||
                cnpj == "55555555555555" ||
                cnpj == "66666666666666" ||
                cnpj == "77777777777777" ||
                cnpj == "88888888888888" ||
                cnpj == "99999999999999")
                return false;
        
         
            tamanho = cnpj.length - 2
            numeros = cnpj.substring(0, tamanho);
            digitos = cnpj.substring(tamanho);
            soma = 0;
            pos = tamanho - 7;
            for (i = tamanho; i >= 1; i--) {
                soma += numeros.charAt(tamanho - i) * pos--;
                if (pos < 2)
                    pos = 9;
            }
            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
            if (resultado != digitos.charAt(0)) return false;
            tamanho = tamanho + 1;
            numeros = cnpj.substring(0, tamanho);
            soma = 0;
            pos = tamanho - 7;
            for (i = tamanho; i >= 1; i--) {
                soma += numeros.charAt(tamanho - i) * pos--;
                if (pos < 2)
                    pos = 9;
            }
            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
            if (resultado != digitos.charAt(1))
                return false;
        
            return true;
        
        }







        

















    }
})()
