Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Web.UI
Imports System.Threading


Partial Class VB

    Inherits System.Web.UI.Page

    'Public Sub Upload(sender As Object, e As EventArgs)

    '    Thread.Sleep(2000)

    '    Dim arquivos As HttpFileCollection = Request.Files()
    '    For x As Integer = 0 To arquivos.Count - 1 'Each key As String In arquivos.Keys
    '        Dim arquivo As HttpPostedFile = arquivos(x)
    '        Dim filename As String = arquivo.FileName
    '        Dim contentType As String = arquivo.ContentType
    '        Using fs As Stream = arquivo.InputStream
    '            Using br As New BinaryReader(fs)
    '                Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))
    '                Dim constr As String = ConfigurationManager.ConnectionStrings("prod").ConnectionString
    '                Using conn As New SqlConnection(constr)
    '                    Dim query As String = "insert into contato.dbo.tblFiles values (@Name, @ContentType, @contato, @Data)"
    '                    Using cmd As New SqlCommand(query)
    '                        cmd.Connection = conn
    '                        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = filename
    '                        cmd.Parameters.Add("@contentType", SqlDbType.VarChar).Value = contentType
    '                        cmd.Parameters.Add("@contato", SqlDbType.BigInt).Value = idContato.Value
    '                        cmd.Parameters.Add("@data", SqlDbType.VarBinary).Value = bytes
    '                        conn.Open()
    '                        cmd.ExecuteNonQuery()
    '                        conn.Close()
    '                    End Using
    '                End Using
    '            End Using
    '        End Using
    '    Next

    'End Sub

    'Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
    '       If IsPostBack Then
    '           'Thread.Sleep(2000)

    '           Dim arquivos As HttpFileCollection = Request.Files()
    '           For x As Integer = 0 To arquivos.Count - 1 'Each key As String In arquivos.Keys
    '               Dim arquivo As HttpPostedFile = arquivos(x)
    '               Dim filename As String = arquivo.FileName
    '               Dim contentType As String = arquivo.ContentType
    '               Using fs As Stream = arquivo.InputStream
    '                   Using br As New BinaryReader(fs)
    '                       Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))
    '                       Dim constr As String = ConfigurationManager.ConnectionStrings("prod").ConnectionString
    '                       Using conn As New SqlConnection(constr)
    '                           Dim query As String = "insert into contato.dbo.tblFiles values (@Name, @ContentType, @contato, @Data)"
    '                           Using cmd As New SqlCommand(query)
    '                               cmd.Connection = conn
    '                               cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = filename
    '                               cmd.Parameters.Add("@contentType", SqlDbType.VarChar).Value = contentType
    '                               cmd.Parameters.Add("@contato", SqlDbType.BigInt).Value = Request("idContato")
    '                               cmd.Parameters.Add("@data", SqlDbType.VarBinary).Value = bytes
    '                               conn.Open()
    '                               cmd.ExecuteNonQuery()
    '                               conn.Close()
    '                           End Using
    '                       End Using
    '                   End Using
    '               End Using
    '           Next
    '       End If
    '   End Sub

End Class