(function() {
  'use strict'

  var module = angular.module(
    'appContato', [
      'ngAside', 
      'ui.bootstrap',
      'ui.mask',
      'ngLocale',
      'ngSanitize',
      'ngBootbox',
      'oc.lazyLoad'
    ]);
 
  //Configurações de cache
    function noCache(url) {
      return    url.indexOf('uib/') == -1 // nao falha com modals do bootstrap-ui
             && url.indexOf('\.asmx/') == -1 // nao envia como argumento
             && url.indexOf('/apps_legado/') == -1 // nao interfere com portal antigo
             && url.indexOf('?') == -1
             && url.indexOf('&') == -1
             && url.indexOf('ui-grid') == -1
             && url.indexOf('tpl') == -1
             //&& url.indexOf(/.(jpg|gif|png|jpeg|mp4|mp3|avi)$/) == -1 // deixa multimidia no cache
    }
  
    //no jquery
    $.ajaxSetup({
      cache: false,
      headers: {
        "If-Modified-Since": "Mon, 26 Jul 1997 05:00:00 GMT",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache"/*,
        "bestera": "funfou"*/
      },
      beforeSend: function( xhr, options ) {
        //console.log(options.url);
        if (noCache(options.url))
          options.url += Date.now();
      }
    }); 

    //no angular
    module.config(function($httpProvider){
      $httpProvider.interceptors.push(function() {
        return {
          'request': function(config) {
            //console.log(config.url);
            if (noCache(config.url))
              config.url += '?' + Date.now();
            return config;
          }
        };
      });

      $httpProvider.defaults.useXDomain = true; 

      if (!$httpProvider.defaults.headers.get) {
         $httpProvider.defaults.headers.get = {};    
      }    

      delete $httpProvider.defaults.headers.common['X-Requested-With'];

      //disable IE ajax request caching
      $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
      // extra
      $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
      $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
      //$httpProvider.defaults.headers.get['bestera'] = 'funfou';
    });
  
    /*
    module.run(function($templateCache){
      $templateCache.removeAll();
    });
    */
  
  //////// fim cache
  
  
  //Configuração para poder declarar os js (controller/service/factory/etc) no html dos modulos
  module.config(function ($controllerProvider, $provide, $compileProvider, $filterProvider) {
    // Since the "shorthand" methods for component
    // definitions are no longer valid, we can just
    // override them to use the providers for post-
    // bootstrap loading.
    // Let's keep the older references.
    module._controller = module.controller;
    module._service = module.service;
    module._factory = module.factory;
    module._value = module.value;
    module._directive = module.directive;
    module._filter = module.filter;

    // Provider-based controller.
    module.controller = function (name, constructor) {
      $controllerProvider.register(name, constructor);
      return (this);
    };
    // Provider-based service.
    module.service = function (name, constructor) {
      $provide.service(name, constructor);
      return (this);
    };
    // Provider-based factory.
    module.factory = function (name, factory) {
      $provide.factory(name, factory);
      return (this);
    };
    // Provider-based value.
    module.value = function (name, value) {
      $provide.value(name, value);
      return (this);
    };
    // Provider-based directive.
    module.directive = function (name, factory) {
      $compileProvider.directive(name, factory);
      return (this);
    };
    
    module.filter = function (name, filter) {
      $filterProvider.register(name, filter);
      return (this);
    };

  });
  
  //Production mode (faster)
  module.config(['$compileProvider', function ($compileProvider) {
      $compileProvider.aHrefSanitizationWhitelist(/^\s*(|blob|):/);
    //$compileProvider.debugInfoEnabled(false);
  }]);
  
  //Disponibiliza Modernizr aos módulos
  module.constant("Modernizr", Modernizr);

  
  //https://www.abeautifulsite.net/vertically-centering-bootstrap-modals/
  function modalRepositioning(){
    function reposition() {
      var modal = $(this),
          dialog = modal.find('.modal-dialog');
      modal.css('display', 'block');

      // Dividing by two centers the modal exactly, but dividing by three 
      // or four works better for larger screens.
      dialog.css("margin-top", Math.max(0, ($(window).height() - dialog.height()) / 2));
    }
  
    // Reposition when a modal is shown
    $('.modal').on('show.bs.modal', reposition);
  
    // Reposition when the window is resized
    $(window).on('resize', function() {
        $('.modal:visible').each(reposition);
    });
  }
  modalRepositioning();
  
 // Exibir melhor erros no log
  module.config(function logConfig($provide, $logProvider) {
    $provide.decorator('$log', function ($delegate) {
      var originalFns = {};

      // Store the original log functions
      angular.forEach($delegate, function (originalFunction, functionName) {
        originalFns[functionName] = originalFunction;
      });

      var functionsToDecorate = ['debug', 'warn'];

      // Apply the decorations
      angular.forEach(functionsToDecorate, function (functionName) {
        $delegate[functionName] = logDecorator(originalFns[functionName]);
      });

      return $delegate;
    });
  
    function logDecorator(fn) {
      return function () {

        var args = [].slice.call(arguments);

        // Insert a separator between the existing log message(s) and what we're adding.
        args.push(' - ');

        // Use (instance of Error)'s stack to get the current line.
        var newErr = new Error();

        // phantomjs does not support Error.stack and falls over so we will skip it
        if (typeof newErr.stack !== 'undefined') {
          var stack = newErr.stack.split('\n').slice(1);

          if (navigator.userAgent.indexOf("Chrome") > -1) {
            stack.shift();
          }
          stack = stack.slice(0, 1);

          var stackInString = stack + '';
          var splitStack;
          if (navigator.userAgent.indexOf("Chrome") > -1) {
            splitStack = stackInString.split(" ");
          } else {
            splitStack = stackInString.split("@");
          }
          var lineLocation = splitStack[splitStack.length - 1];
          // Put it on the args stack.
          args.push(lineLocation);

          // Call the original function with the new args.
          fn.apply(fn, args);
        }
      };
    }
  })
  //end Log Erros 

})()